# npass

> nPass

[![NPM](https://img.shields.io/npm/v/npass.svg)](https://www.npmjs.com/package/npass) [![JavaScript Style Guide](https://img.shields.io/badge/code_style-standard-brightgreen.svg)](https://standardjs.com)

## Install

```bash
npm install --save npass
```

## License

MIT © [tjl-dev](https://github.com/tjl-dev/npass)
